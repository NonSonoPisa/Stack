public class Mostro implements CharacterCreate{
 
    @Override
    public void character(String text) {
        System.out.println("Tipo del mostro: "+text);
    }
 
}

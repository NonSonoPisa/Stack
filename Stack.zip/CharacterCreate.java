public interface CharacterCreate {
     
  public void character(String text);
 
}

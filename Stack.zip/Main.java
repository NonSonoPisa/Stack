    public void main(String[] args) {
  
        CharacterCreate character = new Personaggio();
        Personaggio editor = new Personaggio(character);
        editor.publishText("Nano");
         
        character = new Mostro();
        editor = new Personaggio(character);
        editor.publishText("Orco");
 
    }

public class Personaggio {
     
    private final CharacterCreate characterCreate;
     
    public Personaggio(CharacterCreate characterCreate){
        this.characterCreate = characterCreate;
    }
     
    public void publishText(String text){
        characterCreate.character(text);
    }
 
}

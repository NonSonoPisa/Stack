public class Eroe implements CharacterCreate{
 
    @Override
    public void character(String text) {
        System.out.println("Tipo di Eroe: "+text);
    }
 
}
